package buscaBinaria;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		
		BinarySearch binarySearch = new BinarySearch();
		Vetor vetor = new Vetor();		
		vetor.fillVector();		
		
		int valaorBuscado = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor que deseja buscar:"));
				
		binarySearch.buscaSequencial(valaorBuscado, vetor.getVetor());
			
	}

}