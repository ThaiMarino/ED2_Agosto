package buscaBinaria;

import java.util.Arrays;
import java.util.Iterator;

import javax.swing.JOptionPane;

public class Vetor {
	private int[] vetor;
	private int sizeOf;
	
	public Vetor() {
		sizeOf = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho desejado do vetor: " ));
		vetor = new int[sizeOf];
	}
	
	public void fillVector() {
		for(int i = 0; i < sizeOf ; i++) {
			vetor[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o número do índice " + i + ":"));
		}
	}
	public void printVector() {		
		for(int i = 0; i < sizeOf ; i++) {
			JOptionPane.showMessageDialog(null, vetor);
		}
	}

	public int[] getVetor() {
		return vetor;
	}

	@Override
	public String toString() {
		return "Vetor [vetor=" + Arrays.toString(vetor) + "]";
	}
	
		
}
