package buscaBinaria;

import javax.swing.JOptionPane;

public class BinarySearch {
	private Boolean find = false;
	
	public void buscaSequencial(int valorBuscado, int[] vetor) {
		for(int i = 0; i < vetor.length ; i++) {
			if(valorBuscado == vetor[i]) {
				find = true;
				break;
			}
		}
		if(find) {
			JOptionPane.showMessageDialog(null, "Valor Achado!: " + valorBuscado);
		}else {
			JOptionPane.showMessageDialog(null, "Valor Não encontrado!: " + valorBuscado);
		}
	}
}
